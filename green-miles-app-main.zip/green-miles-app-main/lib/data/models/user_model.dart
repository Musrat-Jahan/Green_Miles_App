class UserModel {
  final String uid;
  final String name;
  final String email;
  final String profileImageUrl;
  final int points;
  final double totalCo2Saved;
  final double totalDistance;
  final int totalTrips;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    this.profileImageUrl = '',
    this.points = 0,
    this.totalCo2Saved = 0.0,
    this.totalDistance = 0.0,
    this.totalTrips = 0,
  });

  // Factory constructor for creating a new UserModel instance from a map
  factory UserModel.fromMap(Map<String, dynamic> data, String documentId) {
    return UserModel(
      uid: documentId,
      name: data['name'] ?? '',
      email: data['email'] ?? '',
      profileImageUrl: data['profileImageUrl'] ?? '',
      points: data['points'] ?? 0,
      totalCo2Saved: (data['totalCo2Saved'] ?? 0.0).toDouble(),
      totalDistance: (data['totalDistance'] ?? 0.0).toDouble(),
      totalTrips: data['totalTrips'] ?? 0,
    );
  }

  // Method to convert a UserModel instance to a map
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'profileImageUrl': profileImageUrl,
      'points': points,
      'totalCo2Saved': totalCo2Saved,
      'totalDistance': totalDistance,
      'totalTrips': totalTrips,
    };
  }
}

