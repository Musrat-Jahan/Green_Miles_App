class RewardModel {
  final String id;
  final String title;
  final String description;
  final int points;
  final String imageUrl;

  RewardModel({
    required this.id,
    required this.title,
    required this.description,
    required this.points,
    required this.imageUrl,
  });
}

