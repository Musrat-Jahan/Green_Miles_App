import 'package:flutter/material.dart';

enum TransportMode {
  walk,
  bicycle,
  publicTransport,
  electricVehicle,
  car,
}

class TripModel {
  final String id;
  final String userId;
  final TransportMode transportMode;
  final DateTime startTime;
  final DateTime endTime;
  final double distance; // in kilometers
  final double co2Saved; // in kilograms
  // Could also include a polyline of the route
  // final List<LatLng> route;

  TripModel({
    required this.id,
    required this.userId,
    required this.transportMode,
    required this.startTime,
    required this.endTime,
    required this.distance,
    required this.co2Saved,
  });

  Duration get duration => endTime.difference(startTime);

  // Helper to get icon for transport mode
  IconData get transportIcon {
    switch (transportMode) {
      case TransportMode.walk:
        return Icons.directions_walk;
      case TransportMode.bicycle:
        return Icons.directions_bike;
      case TransportMode.publicTransport:
        return Icons.directions_bus;
      case TransportMode.electricVehicle:
        return Icons.electric_car;
      case TransportMode.car:
        return Icons.directions_car;
    }
  }
}

