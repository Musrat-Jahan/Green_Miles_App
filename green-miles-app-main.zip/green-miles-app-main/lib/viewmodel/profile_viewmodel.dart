import 'package:flutter/foundation.dart';
import 'package:green_miles_app/data/models/trip_model.dart';
import 'package:green_miles_app/data/models/user_model.dart';

class ProfileViewModel extends ChangeNotifier {
  UserModel? _user;
  List<TripModel> _tripHistory = [];
  bool _isLoading = false;

  UserModel? get user => _user;
  List<TripModel> get tripHistory => _tripHistory;
  bool get isLoading => _isLoading;

  ProfileViewModel() {
    fetchProfileData();
  }

  Future<void> fetchProfileData() async {
    _isLoading = true;
    notifyListeners();

    await Future.delayed(const Duration(seconds: 1)); // Simulate network call

    _user = UserModel(
      uid: '123',
      name: 'Alex',
      email: 'alex@example.com',
      profileImageUrl: 'https://i.pravatar.cc/150?img=10',
      points: 3250,
      totalCo2Saved: 175.8,
      totalDistance: 850.2,
      totalTrips: 42,
    );

    _tripHistory = [
      TripModel(id: 't1', userId: '123', transportMode: TransportMode.bicycle, startTime: DateTime.now().subtract(const Duration(days: 1, hours: 2)), endTime: DateTime.now().subtract(const Duration(days: 1, hours: 1)), distance: 10.5, co2Saved: 2.1),
      TripModel(id: 't2', userId: '123', transportMode: TransportMode.walk, startTime: DateTime.now().subtract(const Duration(days: 2, hours: 4)), endTime: DateTime.now().subtract(const Duration(days: 2, hours: 3)), distance: 3.2, co2Saved: 0.8),
      TripModel(id: 't3', userId: '123', transportMode: TransportMode.publicTransport, startTime: DateTime.now().subtract(const Duration(days: 4, hours: 1)), endTime: DateTime.now().subtract(const Duration(days: 4)), distance: 25.0, co2Saved: 4.5),
      TripModel(id: 't4', userId: '123', transportMode: TransportMode.electricVehicle, startTime: DateTime.now().subtract(const Duration(days: 5, hours: 6)), endTime: DateTime.now().subtract(const Duration(days: 5, hours: 5)), distance: 15.1, co2Saved: 0.5),
    ];

    _isLoading = false;
    notifyListeners();
  }
}

