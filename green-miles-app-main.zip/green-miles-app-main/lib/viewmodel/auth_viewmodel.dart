import 'package:flutter/foundation.dart';

class AuthViewModel extends ChangeNotifier {
  bool _isLoading = false;
  String? _error;
  bool _isAuthenticated = false;

  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _isAuthenticated;

  Future<void> signIn({required String email, required String password}) async {
    _setLoading(true);
    await Future.delayed(const Duration(milliseconds: 800));
    // Mock success if both fields are non-empty
    if (email.isNotEmpty && password.isNotEmpty) {
      _isAuthenticated = true;
      _error = null;
    } else {
      _error = 'Invalid credentials';
      _isAuthenticated = false;
    }
    _setLoading(false);
  }

  Future<void> signUp({required String name, required String email, required String password}) async {
    _setLoading(true);
    await Future.delayed(const Duration(milliseconds: 1000));
    if (name.isNotEmpty && email.isNotEmpty && password.length >= 6) {
      _isAuthenticated = true;
      _error = null;
    } else {
      _error = 'Please fill all fields';
      _isAuthenticated = false;
    }
    _setLoading(false);
  }

  void logout() {
    _isAuthenticated = false;
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}

