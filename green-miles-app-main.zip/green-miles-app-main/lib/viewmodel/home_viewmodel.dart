import 'package:flutter/material.dart';
import 'package:green_miles_app/data/models/carbon_stat_model.dart';
import 'package:green_miles_app/data/models/trip_model.dart';
import 'package:green_miles_app/data/models/user_model.dart';

class HomeViewModel extends ChangeNotifier {
  // Private properties
  UserModel? _user;
  double _weeklyCo2Saved = 0.0;
  List<CarbonStatModel> _dailyStats = [];
  bool _isLoading = false;

  // Public getters
  UserModel? get user => _user;
  double get weeklyCo2Saved => _weeklyCo2Saved;
  List<CarbonStatModel> get dailyStats => _dailyStats;
  bool get isLoading => _isLoading;

  // Constructor
  HomeViewModel() {
    // Fetch data when the ViewModel is created
    fetchDashboardData();
  }

  // --- Public Methods ---

  Future<void> fetchDashboardData() async {
    _setLoading(true);

    // Simulate a network call
    await Future.delayed(const Duration(seconds: 2));

    // --- Mock Data ---
    _user = UserModel(
      uid: '123',
      name: 'Alex',
      email: 'alex@example.com',
    );

    _weeklyCo2Saved = 12.7; // Example: 12.7 kg CO2 saved

    _dailyStats = _getMockDailyStats();
    // --- End Mock Data ---

    _setLoading(false);
  }

  // --- Private Methods ---

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  List<CarbonStatModel> _getMockDailyStats() {
    final today = DateTime.now();
    return [
      CarbonStatModel(mode: TransportMode.bicycle, co2Saved: 1.2, date: today.subtract(const Duration(days: 6))), // Mon
      CarbonStatModel(mode: TransportMode.walk, co2Saved: 0.8, date: today.subtract(const Duration(days: 5))),    // Tue
      CarbonStatModel(mode: TransportMode.publicTransport, co2Saved: 2.5, date: today.subtract(const Duration(days: 4))), // Wed
      CarbonStatModel(mode: TransportMode.bicycle, co2Saved: 1.5, date: today.subtract(const Duration(days: 3))), // Thu
      CarbonStatModel(mode: TransportMode.electricVehicle, co2Saved: 3.0, date: today.subtract(const Duration(days: 2))), // Fri
      CarbonStatModel(mode: TransportMode.walk, co2Saved: 1.0, date: today.subtract(const Duration(days: 1))),    // Sat
      CarbonStatModel(mode: TransportMode.bicycle, co2Saved: 2.7, date: today), // Sun
    ];
  }
}

