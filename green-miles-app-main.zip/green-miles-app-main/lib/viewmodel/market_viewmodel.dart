import 'package:flutter/foundation.dart';
import 'package:green_miles_app/data/models/reward_model.dart';

class MarketViewModel extends ChangeNotifier {
  List<RewardModel> _rewards = [];
  bool _isLoading = false;

  List<RewardModel> get rewards => _rewards;
  bool get isLoading => _isLoading;

  MarketViewModel() {
    fetchRewards();
  }

  Future<void> fetchRewards() async {
    _isLoading = true;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 900)); // Simulate network call

    _rewards = [
      RewardModel(id: '1', title: 'Reusable Coffee Cup', description: 'A stylish, eco-friendly cup.', points: 500, imageUrl: 'https://images.unsplash.com/photo-1584486188544-dc57f2593216?w=500'),
      RewardModel(id: '2', title: 'Plant a Tree', description: 'We plant a tree in your name.', points: 1000, imageUrl: 'https://images.unsplash.com/photo-1512428209919-85eff0a8535a?w=500'),
      RewardModel(id: '3', title: 'Eco-friendly Tote Bag', description: 'Durable and made from recycled materials.', points: 750, imageUrl: 'https://images.unsplash.com/photo-1594499468121-f45e83e3e4fe?w=500'),
      RewardModel(id: '4', title: 'Bamboo Toothbrush Set', description: 'A set of 4 biodegradable toothbrushes.', points: 400, imageUrl: 'https://images.unsplash.com/photo-1619095932430-cb382272b48a?w=500'),
      RewardModel(id: '5', title: 'Solar Power Bank', description: 'Charge your devices with the sun.', points: 2500, imageUrl: 'https://images.unsplash.com/photo-1618503308043-5b51a6b7b953?w=500'),
      RewardModel(id: '6', title: 'Donation to WWF', description: 'Support wildlife conservation.', points: 1500, imageUrl: 'https://images.unsplash.com/photo-1474511320723-9a56873867b5?w=500'),
    ];

    _isLoading = false;
    notifyListeners();
  }
}

