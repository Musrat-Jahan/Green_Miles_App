import 'package:flutter/foundation.dart';
import 'package:green_miles_app/data/models/user_model.dart';

enum LeaderboardPeriod { weekly, monthly, allTime }

class LeaderboardViewModel extends ChangeNotifier {
  // Private properties
  LeaderboardPeriod _selectedPeriod = LeaderboardPeriod.weekly;
  List<UserModel> _users = [];
  bool _isLoading = false;

  // Public getters
  LeaderboardPeriod get selectedPeriod => _selectedPeriod;
  List<UserModel> get users => _users;
  bool get isLoading => _isLoading;

  // Constructor
  LeaderboardViewModel() {
    // Fetch initial data
    fetchLeaderboard();
  }

  // --- Public Methods ---

  Future<void> fetchLeaderboard() async {
    _setLoading(true);
    // Simulate a network call based on the selected period
    await Future.delayed(const Duration(milliseconds: 800));

    // --- Mock Data ---
    // In a real app, this would be a repository call fetching users
    // and sorting them by CO2 saved for the selected period.
    _users = _getMockUsers();
    // --- End Mock Data ---

    _setLoading(false);
  }

  void setPeriod(LeaderboardPeriod period) {
    if (_selectedPeriod != period) {
      _selectedPeriod = period;
      notifyListeners(); // Notify listeners to update the UI for the selected tab
      fetchLeaderboard(); // Fetch new data for the selected period
    }
  }

  // --- Private Methods ---

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  List<UserModel> _getMockUsers() {
    // Create a list of mock users with varying stats based on the period
    var mockUsers = [
      UserModel(uid: '1', name: 'Sophia', email: '', totalCo2Saved: 150.5, profileImageUrl: 'https://i.pravatar.cc/150?img=1'),
      UserModel(uid: '2', name: 'Liam', email: '', totalCo2Saved: 142.8, profileImageUrl: 'https://i.pravatar.cc/150?img=2'),
      UserModel(uid: '3', name: 'Olivia', email: '', totalCo2Saved: 130.2, profileImageUrl: 'https://i.pravatar.cc/150?img=3'),
      UserModel(uid: '4', name: 'Noah', email: '', totalCo2Saved: 115.9, profileImageUrl: 'https://i.pravatar.cc/150?img=4'),
      UserModel(uid: '5', name: 'Ava', email: '', totalCo2Saved: 105.1, profileImageUrl: 'https://i.pravatar.cc/150?img=5'),
      UserModel(uid: '6', name: 'William', email: '', totalCo2Saved: 98.4, profileImageUrl: 'https://i.pravatar.cc/150?img=6'),
      UserModel(uid: '7', name: 'Isabella', email: '', totalCo2Saved: 88.7, profileImageUrl: 'https://i.pravatar.cc/150?img=7'),
      UserModel(uid: '8', name: 'James', email: '', totalCo2Saved: 76.3, profileImageUrl: 'https://i.pravatar.cc/150?img=8'),
    ];

    // Shuffle and adjust scores based on period for variety
    double multiplier = 1.0;
    switch (_selectedPeriod) {
      case LeaderboardPeriod.weekly:
        multiplier = 0.25;
        break;
      case LeaderboardPeriod.monthly:
        multiplier = 0.6;
        break;
      case LeaderboardPeriod.allTime:
        multiplier = 1.0;
        break;
    }

    return mockUsers.map((user) {
      return UserModel(
        uid: user.uid,
        name: user.name,
        email: user.email,
        profileImageUrl: user.profileImageUrl,
        totalCo2Saved: user.totalCo2Saved * multiplier,
      );
    }).toList()..sort((a, b) => b.totalCo2Saved.compareTo(a.totalCo2Saved));
  }
}

