import 'package:flutter/foundation.dart';

class SplashViewModel extends ChangeNotifier {
  bool _isChecking = true;
  bool _isAuthenticated = false; // mock flag for now

  bool get isChecking => _isChecking;
  bool get isAuthenticated => _isAuthenticated;

  SplashViewModel() {
    _init();
  }

  Future<void> _init() async {
    await Future.delayed(const Duration(seconds: 2));
    _isChecking = false;
    notifyListeners();
  }
}

