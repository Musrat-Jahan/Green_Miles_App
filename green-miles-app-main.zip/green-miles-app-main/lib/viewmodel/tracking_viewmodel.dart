import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:green_miles_app/data/models/trip_model.dart';
import 'package:location/location.dart';

enum TrackingState { idle, tracking, paused }

class TrackingViewModel extends ChangeNotifier {
  // --- Private Properties ---
  final Location _location = Location();
  GoogleMapController? _mapController;
  StreamSubscription<LocationData>? _locationSubscription;

  TrackingState _trackingState = TrackingState.idle;
  TransportMode _selectedTransportMode = TransportMode.bicycle;
  LocationData? _currentLocation;
  final Set<Polyline> _polylines = {};
  final List<LatLng> _routePoints = [];
  Timer? _timer;
  int _tripDurationInSeconds = 0;

  // --- Public Getters ---
  TrackingState get trackingState => _trackingState;
  TransportMode get selectedTransportMode => _selectedTransportMode;
  LocationData? get currentLocation => _currentLocation;
  Set<Polyline> get polylines => _polylines;
  int get tripDurationInSeconds => _tripDurationInSeconds;
  GoogleMapController? get mapController => _mapController;

  // --- Constructor ---
  TrackingViewModel() {
    // _requestPermissionAndGetCurrentLocation();
  }

  // --- Public Methods ---

  void onMapCreated(GoogleMapController controller) {
    _mapController = controller;
    // You can set custom map styles here if you want
  }

  void setTransportMode(TransportMode mode) {
    _selectedTransportMode = mode;
    notifyListeners();
  }

  void startTrip() {
    if (_trackingState == TrackingState.idle) {
      _trackingState = TrackingState.tracking;
      _routePoints.clear();
      _polylines.clear();
      _tripDurationInSeconds = 0;
      // _startLocationUpdates();
      _startTimer();
      notifyListeners();
    }
  }

  void stopTrip() {
    if (_trackingState == TrackingState.tracking || _trackingState == TrackingState.paused) {
      _trackingState = TrackingState.idle;
      _locationSubscription?.cancel();
      _timer?.cancel();
      // Here you would calculate distance, CO2 saved, and save the trip
      // For now, we just reset
      notifyListeners();
    }
  }

  // --- Private Methods ---

  Future<void> _requestPermissionAndGetCurrentLocation() async {
    bool serviceEnabled = await _location.serviceEnabled();
    if (!serviceEnabled) {
      // serviceEnabled = await _location.requestService();
      // if (!serviceEnabled) return;
      return;
    }

    PermissionStatus permissionGranted = await _location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      // permissionGranted = await _location.requestPermission();
      // if (permissionGranted != PermissionStatus.granted) return;
      return;
    }

    _currentLocation = await _location.getLocation();
    _mapController?.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(_currentLocation!.latitude!, _currentLocation!.longitude!),
          zoom: 16.0,
        ),
      ),
    );
    notifyListeners();
  }

  void _startLocationUpdates() {
    _locationSubscription = _location.onLocationChanged.listen((LocationData newLocation) {
      _currentLocation = newLocation;
      if (_trackingState == TrackingState.tracking) {
        final latLng = LatLng(newLocation.latitude!, newLocation.longitude!);
        _routePoints.add(latLng);
        _updatePolylines();
      }
      notifyListeners();
    });
  }

  void _updatePolylines() {
    _polylines.clear();
    _polylines.add(
      Polyline(
        polylineId: const PolylineId('trip_route'),
        points: _routePoints,
        color: Colors.blue,
        width: 5,
      ),
    );
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _tripDurationInSeconds++;
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _locationSubscription?.cancel();
    _mapController?.dispose();
    _timer?.cancel();
    super.dispose();
  }
}

