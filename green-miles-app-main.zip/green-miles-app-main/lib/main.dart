import 'package:flutter/material.dart';
import 'package:green_miles_app/core/app_strings.dart';
import 'package:green_miles_app/core/app_theme.dart';
import 'package:green_miles_app/view/onboarding/splash_screen.dart';
import 'package:provider/provider.dart';

import 'viewmodel/auth_viewmodel.dart';
import 'viewmodel/home_viewmodel.dart';
import 'viewmodel/leaderboard_viewmodel.dart';
import 'viewmodel/market_viewmodel.dart';
import 'viewmodel/profile_viewmodel.dart';
import 'viewmodel/splash_viewmodel.dart';
import 'viewmodel/tracking_viewmodel.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => HomeViewModel()),
        ChangeNotifierProvider(create: (_) => LeaderboardViewModel()),
        ChangeNotifierProvider(create: (_) => TrackingViewModel()),
        ChangeNotifierProvider(create: (_) => MarketViewModel()),
        ChangeNotifierProvider(create: (_) => ProfileViewModel()),
        ChangeNotifierProvider(create: (_) => AuthViewModel()),
        ChangeNotifierProvider(create: (_) => SplashViewModel()),
        // Add other ViewModels here as the app grows
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppStrings.appName,
      theme: AppTheme.lightTheme,
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
