class AppStrings {
  // Private constructor
  AppStrings._();

  // --- General ---
  static const String appName = "Green Miles";

  // --- Onboarding ---
  static const String welcomeTitle = "Make Carbon Visible.";
  static const String welcomeSubtitle = "Track your transport, reduce your footprint, and earn rewards for a greener planet.";
  static const String onboardingTitleOne = "Track Every Green Trip";
  static const String onboardingDescOne = "Log your rides and walks to see real-time impact in one place.";
  static const String onboardingTitleTwo = "See Your Carbon Savings";
  static const String onboardingDescTwo = "Watch weekly insights and progress with clean, simple stats.";
  static const String onboardingTitleThree = "Earn Rewards";
  static const String onboardingDescThree = "Turn eco-friendly miles into points and redeem rewards.";
  static const String getStarted = "Get Started";
  static const String next = "Next";
  static const String skip = "Skip";
  static const String signIn = "Sign In";
  static const String signUp = "Sign Up";
  static const String locationPermissionTitle = "Enable Location";
  static const String locationPermissionDesc = "Green Miles needs your location to track your trips and calculate your carbon savings automatically.";
  static const String allowLocation = "Allow Location";
  static const String denyLocation = "Not Now";
  static const String splashTagline = "Track. Save. Earn.";
  static const String welcomeBack = "Welcome back";
  static const String createAccount = "Create Account";
  static const String emailLabel = "Email";
  static const String passwordLabel = "Password";
  static const String confirmPasswordLabel = "Confirm Password";
  static const String nameLabel = "Full Name";
  static const String forgotPassword = "Forgot password?";
  static const String dontHaveAccount = "Don't have an account?";
  static const String alreadyHaveAccount = "Already have an account?";
  static const String continueCta = "Continue";
  static const String or = "or";
  static const String signInWithEmail = "Sign in with email";
  static const String signUpWithEmail = "Sign up with email";
  static const String permissionsNeeded = "Permissions Needed";
  static const String locationDenied = "Location access is required to track your trips.";
  static const String openSettings = "Open Settings";
  static const String permissionGranted = "Permission granted!";

  // --- Home (Dashboard) ---
  static const String homeGreeting = "Hello,";
  static const String co2SavedThisWeek = "CO₂ Saved This Week";
  static const String dailyStats = "Daily Statistics";
  static const String viewTripHistory = "View Trip History";
  static const String kg = "kg";

  // --- Tracking ---
  static const String startTrip = "Start Trip";
  static const String endTrip = "End Trip";
  static const String selectTransportMode = "Select Mode";
  static const String tripSummary = "Trip Summary";
  static const String distance = "Distance";
  static const String duration = "Duration";
  static const String co2Saved = "CO₂ Saved";

  // --- Transport Modes ---
  static const String car = "Car";
  static const String bicycle = "Bicycle";
  static const String walk = "Walk";
  static const String publicTransport = "Public Transport";
  static const String electricVehicle = "EV";

  // --- Leaderboard ---
  static const String leaderboard = "Ranking";
  static const String ranking = "Ranking";
  static const String weekly = "Weekly";
  static const String monthly = "Monthly";
  static const String allTime = "All-Time";

  // --- Notifications ---
  static const String notifications = "Notifications";
  static const String noNotificationsYet = "No notifications yet";

  // --- Drawer ---
  static const String home = "Home";
  static const String close = "Close";

  // --- Marketplace ---
  static const String marketplace = "Mart";
  static const String points = "Points";
  static const String redeemReward = "Redeem";

  // --- Profile ---
  static const String profile = "Profile";
  static const String myStats = "My Stats";
  static const String tripHistory = "Trip History";
  static const String settings = "Settings";
  static const String logout = "Logout";
  static const String totalDistance = "Total Distance";
  static const String totalTrips = "Total Trips";
  static const String totalCo2Saved = "Total CO₂ Saved";
}
