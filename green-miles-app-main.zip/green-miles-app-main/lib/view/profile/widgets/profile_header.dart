import 'package:flutter/material.dart';
import 'package:green_miles_app/core/app_theme.dart';
import 'package:green_miles_app/data/models/user_model.dart';

class ProfileHeader extends StatelessWidget {
  final UserModel user;

  const ProfileHeader({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: AppTheme.primaryGradient,
            boxShadow: AppTheme.softShadow,
          ),
          child: CircleAvatar(
            radius: 46,
            backgroundImage: NetworkImage(user.profileImageUrl),
            backgroundColor: AppTheme.backgroundColor,
          ),
        ),
        const SizedBox(height: 16),
        Text(user.name, style: textTheme.headlineSmall?.copyWith(color: AppTheme.textColor)),
        const SizedBox(height: 4),
        Text(user.email, style: textTheme.bodyLarge?.copyWith(color: AppTheme.subtitleTextColor)),
      ],
    );
  }
}

