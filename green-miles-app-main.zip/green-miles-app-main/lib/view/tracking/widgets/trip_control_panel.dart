import 'package:flutter/material.dart';
import 'package:green_miles_app/core/app_strings.dart';
import 'package:green_miles_app/core/app_theme.dart';
import 'package:green_miles_app/viewmodel/tracking_viewmodel.dart';

class TripControlPanel extends StatelessWidget {
  final TrackingState trackingState;
  final int durationInSeconds;
  final VoidCallback onStartPressed;
  final VoidCallback onStopPressed;

  const TripControlPanel({
    super.key,
    required this.trackingState,
    required this.durationInSeconds,
    required this.onStartPressed,
    required this.onStopPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (trackingState != TrackingState.idle) _buildStatsRow(context),
            const SizedBox(height: 20),
            _buildControlButton(context),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsRow(BuildContext context) {
    final duration = Duration(seconds: durationInSeconds);
    final String twoDigitMinutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final String twoDigitSeconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildStatItem(context, '0.0 km', AppStrings.distance),
        _buildStatItem(context, '$twoDigitMinutes:$twoDigitSeconds', AppStrings.duration),
        _buildStatItem(context, '0.0 kg', AppStrings.co2Saved),
      ],
    );
  }

  Widget _buildStatItem(BuildContext context, String value, String label) {
    final textTheme = Theme.of(context).textTheme;
    return Column(
      children: [
        Text(
          value,
          style: textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: textTheme.bodyMedium?.copyWith(color: AppTheme.subtitleTextColor),
        ),
      ],
    );
  }

  Widget _buildControlButton(BuildContext context) {
    bool isIdle = trackingState == TrackingState.idle;

    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        icon: Icon(isIdle ? Icons.play_arrow : Icons.stop),
        label: Text(isIdle ? AppStrings.startTrip.toUpperCase() : AppStrings.endTrip.toUpperCase()),
        onPressed: isIdle ? onStartPressed : onStopPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: isIdle ? AppTheme.secondaryColor : Colors.redAccent,
          padding: const EdgeInsets.symmetric(vertical: 20),
          textStyle: Theme.of(context).textTheme.labelLarge?.copyWith(fontSize: 16),
        ),
      ),
    );
  }
}

