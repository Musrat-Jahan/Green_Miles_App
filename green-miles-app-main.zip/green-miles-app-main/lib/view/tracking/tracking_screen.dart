import 'package:flutter/material.dart';
import 'package:green_miles_app/core/app_theme.dart';
import 'package:green_miles_app/viewmodel/tracking_viewmodel.dart';
import 'package:provider/provider.dart';

import 'widgets/transport_mode_selector.dart';
import 'widgets/trip_control_panel.dart';

class TrackingScreen extends StatelessWidget {
  const TrackingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Track New Trip'),
      ),
      body: Consumer<TrackingViewModel>(
        builder: (context, viewModel, child) {
          return Stack(
            children: [
              // Temporary UI-only placeholder while map/API key setup is pending.
              DecoratedBox(
                decoration: const BoxDecoration(gradient: AppTheme.primaryGradient),
                child: Center(
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 28),
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white.withValues(alpha: 0.28)),
                    ),
                    child: const Text(
                      'Map is temporarily disabled for UI development.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ),

              // --- UI Panels ---
              Align(
                alignment: Alignment.bottomCenter,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Transport Mode Selector
                    if (viewModel.trackingState == TrackingState.idle)
                      TransportModeSelector(
                        selectedMode: viewModel.selectedTransportMode,
                        onModeSelected: viewModel.setTransportMode,
                      ),

                    // Trip Control Panel
                    TripControlPanel(
                      trackingState: viewModel.trackingState,
                      durationInSeconds: viewModel.tripDurationInSeconds,
                      onStartPressed: viewModel.startTrip,
                      onStopPressed: viewModel.stopTrip,
                    ),
                  ],
                ),
              )
            ],
          );
        },
      ),
    );
  }
}

